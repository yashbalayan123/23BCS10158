import java.util.*;
import java.util.stream.*;

class Item {
    String title;
    double cost;
    String type;

    public Item(String title, double cost, String type) {
        this.title = title;
        this.cost = cost;
        this.type = type;
    }

    @Override
    public String toString() {
        return title + " | Cost: " + cost + " | Type: " + type;
    }
}

public class ItemStreamDemo {
    public static void main(String[] args) {
        List<Item> items = Arrays.asList(
            new Item("Notebook", 80000, "Electronics"),
            new Item("Mobile", 50000, "Electronics"),
            new Item("Television", 40000, "Electronics"),
            new Item("Kurta", 2000, "Clothing"),
            new Item("Trousers", 2500, "Clothing"),
            new Item("Couch", 30000, "Furniture"),
            new Item("Desk", 15000, "Furniture")
        );

        // Group items by type
        Map<String, List<Item>> grouped = items.stream()
                .collect(Collectors.groupingBy(p -> p.type));
        System.out.println("Items grouped by type:");
        grouped.forEach((cat, list) -> {
            System.out.println(cat + ": " + list);
        });

        // Costliest item in each type
        Map<String, Optional<Item>> maxPrice = items.stream()
                .collect(Collectors.groupingBy(
                        p -> p.type,
                        Collectors.maxBy(Comparator.comparingDouble(p -> p.cost))
                ));
        System.out.println("\nCostliest item in each type:");
        maxPrice.forEach((cat, prod) -> System.out.println(cat + ": " + prod.get()));

        // Average cost of all items
        double avgPrice = items.stream()
                .collect(Collectors.averagingDouble(p -> p.cost));
        System.out.println("\nAverage cost of all items: " + avgPrice);
    }
}
